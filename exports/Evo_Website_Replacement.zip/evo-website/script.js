(() => {
  'use strict';
  const stage = document.querySelector('.journey-stage');
  const steps = document.querySelectorAll('.story-step');
  if (stage && 'IntersectionObserver' in window) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => { if (entry.isIntersecting) stage.dataset.stage = entry.target.dataset.chapter; });
    }, { rootMargin: '-35% 0px -35% 0px', threshold: 0 });
    steps.forEach(step => observer.observe(step));
  }
  const button = document.getElementById('gather');
  const panel = document.getElementById('play-panel');
  const status = document.getElementById('play-status');
  const description = document.getElementById('play-description');
  if (button && panel && status && description) button.addEventListener('click', () => {
    const gathered = button.getAttribute('aria-pressed') !== 'true';
    button.setAttribute('aria-pressed', String(gathered));
    panel.classList.toggle('is-gathered', gathered);
    status.textContent = gathered ? 'Different places. One piece of work.' : 'A document, a page, a note. Scattered.';
    description.textContent = gathered ? 'A small illustration of a better starting point.' : 'See what happens when the pieces find each other.';
    button.innerHTML = gathered ? 'Scatter again <span aria-hidden="true">↺</span>' : 'Bring them together <span aria-hidden="true">↗</span>';
  });
  const year = document.getElementById('year');
  if (year) year.textContent = new Date().getFullYear();
})();
