(() => {
  'use strict';
  const scenes = {
    research: { title: 'A research project', description: 'An idea grows across a document, a few useful pages, and notes you want to come back to.', resources: ['Research outline', 'Useful reading', 'Ideas & questions'] },
    trip: { title: 'A trip taking shape', description: 'A plan comes together through a shared itinerary, places to visit, and little notes along the way.', resources: ['The itinerary', 'Places to explore', 'Things to remember'] },
    project: { title: 'A project in motion', description: 'A promising idea lives in a draft, a source of inspiration, and a few thoughts for what comes next.', resources: ['Project draft', 'Inspiration', 'Next steps'] }
  };
  const buttons = Array.from(document.querySelectorAll('[data-scene]'));
  const title = document.getElementById('scene-title');
  const description = document.getElementById('scene-description');
  const resources = ['resource-one', 'resource-two', 'resource-three'].map(id => document.getElementById(id));
  buttons.forEach(button => button.addEventListener('click', () => {
    const selected = scenes[button.dataset.scene];
    if (!selected) return;
    buttons.forEach(item => { const active = item === button; item.classList.toggle('is-active', active); item.setAttribute('aria-pressed', String(active)); });
    title.textContent = selected.title;
    description.textContent = selected.description;
    resources.forEach((resource, i) => { resource.textContent = selected.resources[i]; });
  }));
  const year = document.getElementById('year');
  if (year) year.textContent = new Date().getFullYear();
})();
