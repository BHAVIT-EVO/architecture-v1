(() => {
  'use strict';
  const journey = document.querySelector('.journey');
  const screen = document.querySelector('.journey-screen');
  const label = document.querySelector('.visual-state');
  const reduced = window.matchMedia('(prefers-reduced-motion: reduce)');
  let ticking = false;
  const progressBar = document.querySelector('.reading-progress span');
  function updateStory() {
    ticking = false;
    if (progressBar) {
      const total = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
      progressBar.style.transform = `scaleX(${Math.max(0, Math.min(1, window.scrollY / total))})`;
    }
    if (!journey || !screen || reduced.matches) return;
    const rect = journey.getBoundingClientRect();
    const distance = Math.max(1, journey.offsetHeight - window.innerHeight);
    const progress = Math.max(0, Math.min(1, -rect.top / distance));
    const gather = Math.max(0, Math.min(1, (progress - 0.43) / 0.45));
    screen.style.setProperty('--progress', progress.toFixed(4));
    screen.style.setProperty('--g', gather.toFixed(4));
    if (label) label.textContent = progress > .72 ? 'A THREAD FOUND ✳' : progress > .3 ? 'PIECES APART' : 'A LOST THREAD';
  }
  const requestUpdate = () => { if (!ticking) { ticking = true; requestAnimationFrame(updateStory); } };
  window.addEventListener('scroll', requestUpdate, { passive: true });
  window.addEventListener('resize', requestUpdate, { passive: true });
  if (reduced.addEventListener) reduced.addEventListener('change', requestUpdate);
  requestUpdate();
  const button = document.querySelector('#gather');
  const demo = document.querySelector('#demo');
  const status = document.querySelector('#demo-status');
  const description = document.querySelector('#demo-description');
  if (button && demo && status && description) button.addEventListener('click', () => {
    const gathered = button.getAttribute('aria-pressed') !== 'true';
    button.setAttribute('aria-pressed', String(gathered));
    demo.classList.toggle('is-gathered', gathered);
    status.textContent = gathered ? 'Different places. One piece of work.' : 'A document. A page. A note. Scattered.';
    description.textContent = gathered ? 'A little illustration of a better starting point.' : 'See what happens when the pieces find each other.';
    button.innerHTML = gathered ? 'Scatter again <span class="sym" aria-hidden="true">↺</span>' : 'Bring them together <span class="sym" aria-hidden="true">↗</span>';
  });
  const year = document.querySelector('#year');
  if (year) year.textContent = new Date().getFullYear();
})();
