# Evo website — interactive story

A standalone static website, with a scroll-led story, an illustrative interaction, and locally served pixel-art scenes. It has no build process, backend, analytics or external runtime dependencies.

## Run locally

```sh
cd path/to/evo-website
python3 -m http.server 8000
```

Visit `http://localhost:8000`. To replace an existing website, back up its current `site/` first, then copy the contents of this folder into it. This folder does **not** include the previous website's legal pages or downloads; check which production routes need to be preserved or replaced before deploying.

## Before publishing

- Confirm `hello@evo.app` is an inbox you control, or replace both contact links in `index.html`.
- No public installer is linked because the inspected main-branch download page says the first build is not attached. Only add a download link when a real, verified release is available.
- The interactive illustration uses invented example content, not real product data. Never publish `exports/ship-happens/boundary.json` or the private event corpus.
- Add approved privacy and legal pages before a production launch. The trust section is a product-design description, not a legal policy or security certification.
- Test on real phones, desktop browsers, keyboard-only navigation and reduced motion. No formal accessibility or performance certification is claimed.
- The artwork is AI-generated; fonts were copied from the existing Evo website. Verify font licensing and attribution for public distribution.

## Files

- `index.html` — narrative and content
- `style.css` — responsive art direction, transitions, reduced motion
- `script.js` — scroll chapter states and illustrative gather/reset interaction
- `assets/` — generated artwork, logo, locally hosted fonts

Research informing the implementation: https://www.awwwards.com/airpods-pro-wins-site-of-the-month-january.html; https://web.dev/learn/accessibility/motion/; https://www.w3.org/WAI/WCAG22/quickref/.
