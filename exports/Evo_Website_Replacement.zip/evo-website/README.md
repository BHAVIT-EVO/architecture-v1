# Evo website

A standalone static website. The homepage, illustrations, fonts, styles and interaction script are all contained in this folder; no build process, third-party runtime, tracking, backend or private data is required.

## Preview locally

```sh
cd path/to/evo-website
python3 -m http.server 8000
```

Open `http://localhost:8000`. Static hosting can serve this directory directly. To use this in place of the existing site, back up your current `site/` directory and copy this folder's contents into it. Don't copy `exports/ship-happens/boundary.json` or any real event data to the public site.

## Before publishing

- Confirm `hello@evo.app` is an inbox you control, or replace it in `index.html`.
- This version intentionally has no download button, signup form, analytics, legal policy, or unverified installer link. Add working services and reviewed legal pages when ready.
- The interactive workspace is an illustrative, synthetic example—not a live product demo. Product availability and agent integration remain accurately qualified.
- Check the site on actual phones, browsers, keyboard-only navigation and with reduced motion. No claim of formal accessibility certification is made.
- Customize copy, metadata and contact details before launch. Avoid adding a canonical URL until the production domain is confirmed.

## Files

- `index.html`: page and copy
- `style.css`: responsive layout, typography, and reduced-motion support
- `script.js`: local illustrative workspace interaction
- `assets/`: logo, self-hosted fonts and generated pixel artwork

Design research: https://web.dev/learn/accessibility/motion and https://www.w3.org/WAI/WCAG22/quickref/. The hero artwork was AI-generated for this project. Original font files are sourced from the existing Evo site; verify their licensing and retain any applicable attribution when publishing.
