# Evo website — a story about finding your way back

A standalone static website with an illustrated, scroll-responsive narrative, a click-to-gather interaction, locally served cinematic artwork, and a reduced-motion layout. No backend, analytics, CDN, or build process is required.

## Preview locally

```sh
cd path/to/evo-website
python3 -m http.server 8000
```

Open `http://localhost:8000`. To replace your existing site, back up `site/` first and copy the **contents** of this folder into it. This package does not include the previous site's legal pages or installers; plan route redirects and preserve any real production resources before deployment.

## Before publishing

- Confirm `hello@evo.app` is your real inbox, or change the contact links in `index.html`.
- No installer is linked: the inspected main-branch download page says its build isn't attached. Add a download link only when a signed, working release is available.
- The interactive scene is a visual illustration, not the live product. Never publish `exports/ship-happens/boundary.json` or the private event corpus.
- Add reviewed privacy and legal pages before production. Design principles on this site are not a privacy policy or security certification.
- Test on real devices and with assistive technology. Desktop and mobile Chromium, reduced-motion behavior, scroll progression/reversal, the gather/reset interaction, links and basic overflow were checked; that is not a formal accessibility or performance audit.
- Images were AI-generated for this project. Display fonts were copied from the existing Evo site; verify applicable licensing before publication. The locally subset symbol fallback is DejaVu Sans; its license is in `assets/fonts/DejaVu-LICENSE.txt`.

## Files

- `index.html`: story and semantic content
- `style.css`: responsive layout, motion and reduced-motion fallback
- `script.js`: scroll progression and illustrative gather/reset interaction
- `assets/`: artwork, icon and self-hosted fonts

Research references: Awwwards' [Working Stiff Films case study](https://www.awwwards.com/working-stiff-films-case-study.html), [MindMarket case study](https://www.awwwards.com/mindmarket-case-study.html), and [AirPods Pro case study](https://www.awwwards.com/airpods-pro-wins-site-of-the-month-january.html); [web.dev on accessible motion](https://web.dev/learn/accessibility/motion).
