(() => {
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  if (reduced.matches || !window.gsap || !window.ScrollTrigger) return;
  gsap.registerPlugin(ScrollTrigger);
  if (window.Lenis) {
    const lenis = new Lenis({duration: 1.15, smoothWheel: true, syncTouch: false, anchors: true});
    lenis.on('scroll', ScrollTrigger.update);
    gsap.ticker.add(time => lenis.raf(time * 1000));
    gsap.ticker.lagSmoothing(0);
    document.querySelectorAll('a[href^="#"]').forEach(link => link.addEventListener('click', e => {
      const target = document.querySelector(link.getAttribute('href'));
      if (target) { e.preventDefault(); lenis.scrollTo(target); history.replaceState(null, '', link.getAttribute('href')); }
    }));
  }
  gsap.from('.hero-inner > *', {y:24,opacity:0,duration:1.1,stagger:.12,ease:'power3.out',delay:.2});
  gsap.to('.hero-art',{yPercent:12,scale:1.08,ease:'none',scrollTrigger:{trigger:'.hero',start:'top top',end:'bottom top',scrub:true}});
  gsap.utils.toArray('.section-top, .problem-layout, .approach-head, .principle-intro, .steps article, .principle-list article').forEach(el => gsap.from(el,{y:32,opacity:0,duration:.9,ease:'power2.out',scrollTrigger:{trigger:el,start:'top 88%',once:true}}));
  gsap.utils.toArray('.frag').forEach((el,i)=>gsap.from(el,{y:80+(i*20),opacity:0,rotation:(i-1)*12,duration:1.2,ease:'power3.out',scrollTrigger:{trigger:'.fragments',start:'top 80%',once:true}}));
  gsap.to('.bridge-art',{scale:1.12,yPercent:4,ease:'none',scrollTrigger:{trigger:'.bridge',start:'top bottom',end:'bottom top',scrub:true}});
  gsap.from('.product-window',{y:90,opacity:0,scale:.96,ease:'power2.out',scrollTrigger:{trigger:'.product-stage',start:'top 80%',end:'center 60%',scrub:1}});
})();
