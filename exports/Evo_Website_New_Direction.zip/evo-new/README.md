# Evo website

A self-contained static concept site. Open `index.html`, or serve this folder with any static web server. No build step, analytics, cookies or external network dependencies are required. The interface illustration is a concept, not a product screenshot. Contact address is carried over from the existing Evo site; verify it before publishing. No installer is linked because none was verified.

Typography: Space Grotesk, DM Sans and IBM Plex Mono (licenses in assets). Animation: Lenis and GSAP/ScrollTrigger, locally hosted; check GSAP's standard license at https://gsap.com/standard-license/ before commercial deployment. Images are AI-generated concept artwork. Reduced-motion preferences disable scripted animation and smooth scrolling.
