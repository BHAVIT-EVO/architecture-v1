# Master prompt: build Evo’s immersive, playable website

**How to use:** Give everything below the line to a capable design-and-development model with access to a coding workspace and, ideally, tools for visual research, 3D assets, sound, browser testing, and image generation. Attach `visual-target.png` if available; it is an optional, AI-generated atmosphere reference, **not** a finished asset, a mandatory layout, or the quality bar. The three live links below are the primary references. Share Evo’s actual product documentation, a verified installer URL and brand files separately if available.

---

You are acting as a **creative director, senior game designer, narrative designer, 3D art director, technical artist, sound designer, senior front-end/game engineer, accessibility specialist and QA lead**. Your job is to design and deliver a complete, production-ready interactive website for **Evo**—from concept and assets through implementation, testing, and handoff.

## 1. What this project actually is

Evo’s website should be a **genuinely playable, immersive narrative experience**, not a landing page with decorative animation, a mock game made from cards, or a slideshow disguised as a world. A visitor can enter a beautifully crafted world, move around, interact, become curious about a mystery, uncover an unfinished piece of work, and experience the problem of losing context. They should come to understand why Evo exists through their own actions, then be able to learn about the real product and, if available, download it.

The owner particularly admires:

1. **Messenger by Abeto — the closest reference for the playable experience:** https://messenger.abeto.co/ . Study the real-time environment, movement, responsive controls, character scale, environmental details, interaction feedback, camera, music, sound, atmosphere, discovery, quest structure and overall craftsmanship. The lesson is not to copy its characters, setting, look, assets or game loop; it is that the experience feels like a real game, not a website with a 3D background.
2. **Igloo Inc — world-class environmental art and motion:** https://www.igloo.inc/ . Study its commitment to one art direction, spatial composition, material quality, lighting, transitions, sound and sense of place. Again, do not reproduce its identity or assets.
3. **Persepolis Reimagined — scale, atmospheric storytelling and discovery:** https://persepolis.getty.edu/ . Study the journey, presentation of information, cinematic pacing, environment, audio and transitions. Do not copy the historical setting or assets.

These are ambition and quality references, **not permission to scrape, reuse, extract, reverse-engineer or redistribute proprietary models, artwork, code, music, characters or trademarks**. If direct interactive access fails, say so. Use legitimate videos, interviews, studio case studies and public documentation; distinguish first-hand observations from secondary descriptions. Do not pretend to have played or tested a reference when you did not.

A useful secondary reference for environmental wayfinding and visual direction is the discussion of *Firewatch* here: https://www.newyorker.com/tech/annals-of-technology/with-firewatch-olly-moss-brings-his-subversive-touch-to-video-games. For exploration driven by curiosity, see https://www.pointnthink.fr/en/loan-verneau-creative-lead-at-mobius-digital-on-outer-wilds/ . These are design references, not art to copy.

## 2. Non-negotiable creative standard

The audience includes founders, software engineers, corporate leaders and other adults who use computers, while Evo’s ultimate vision is broader: anyone working across digital tools. Treat the player as intelligent and visually sophisticated. A childlike world, toy-like primitive characters, low-effort low-poly island, random abstract objects, flat placeholder terrain, excessive glowing particles and generic AI imagery are **not acceptable**. Playful does not mean childish; suspense does not mean horror; professional does not mean boring or a conventional SaaS page.

Choose and commit to **one** of these two visual approaches based on what you can actually deliver:

- **A fully realized stylized/animated world:** art-directed, coherent, mature, expressive, beautifully lit, with custom-looking environments and characters. Think of the consistency and polish of a high-quality independent game—not a collection of basic cones and boxes. Stylization is intentional, not an excuse for crude or unfinished assets.
- **A convincingly realistic world:** grounded environmental storytelling, believable materials, lighting, scale, characters and animation. Do not use AI-generated still images as a substitute for an interactive environment or claim photorealism for simple geometry.

Do **not** land between these in a way that looks like glossy AI-generated advertising art. Avoid recognizable AI slop: generic stock-image compositions, implausible object details, clashing art styles, repetitive symmetrical architecture, random blobs, meaningless floating glass, excessive gradients, generic futuristic interfaces, clichéd purple/blue neon and images that conceal a lack of interaction. The output must be an original, coherent art direction. Use generated images only as concept development or as appropriately licensed, purposeful assets—not as fake interactive screenshots.

The previous attempt used a tiny, primitive low-poly island with stiff characters and text dialogs. The owner rejected it as a child’s game. **Do not iterate on, reuse or superficially polish that implementation. Reset the visual execution and gameplay quality.**

## 3. The experience and narrative to build

Use this complete narrative premise as your starting point, then develop the dialogue, level layout, interactions and visual details needed to make it excellent. Do not reduce it to a pitch deck, empty design brief or a generic prompt. You are responsible for producing the actual finished experience.

### Player fantasy and narrative promise

The player is helping someone pick up an important project after an interruption. The player discovers that the answer is not a missing file but the **relationship between scattered pieces of work, a changed decision and the reason behind it**.

Working title: **The Thread Between**. Create a better original title if the final concept justifies it.

Setting: a compact but deeply authored workspace and its surroundings—a believable real-life-adjacent place with atmosphere, a few memorable landmarks and a clear sense that people use it. The optional attached concept art suggests a warm workspace, natural surroundings and gentle mystery; it is not a requirement to copy an island, lighthouse, camera angle or color scheme. The final setting must make sense for the story and look compelling to adults.

A character, **Mara**, was preparing a real project for an important demonstration. Her work was interrupted after a test changed the direction. Her old draft, a colleague’s account and a later test result are in different places. A colleague, **Noor**, understands one part of what happened. Mara is safe; suspense comes from uncovering the correct decision and understanding what it means, not inventing a missing-person emergency.

Suggested concrete scenario: an early community-facing path-warning display. An earlier draft used a sun and “PATH OPEN”; after a test, the team chose a wave and “PATH CLOSED” for a particular demonstration state. Present it explicitly as a **fictional demonstration**, not real safety guidance or an actual emergency product. If you find a more emotionally resonant, broadly relatable project, you may replace this scenario only if the interaction still clearly demonstrates the same distinction between a stale isolated item and the latest decision in context. Do not assume every visitor is a founder or programmer.

### A complete, coherent arc

- **Entry and choice:** Visually intriguing opening, immediately clear that this is an interactive Evo story. Give equal, working paths to enter the experience, learn about Evo, and get the app or see honest availability. Never gate product information behind a game. Offer sound on/off before playback; keep controls accessible throughout.
- **First interaction and hook:** Within the first moments, the visitor can move or interact with something that is rewarding in itself. Introduce a small contradiction: the old draft appears plausible, but a note or event implies the project changed. Show rather than explain. Establish a human reason the decision matters.
- **Explore and discover:** Offer at least two meaningful locations or routes that can be investigated in either order. A colleague’s dialogue, physical artifact, work trace and environmental details each add a different piece of understanding. Players can inspect, manipulate and talk; the world reacts with animation and sound. Avoid a sequence of cards where “interaction” is just Next.
- **Make an inference:** Give the player a genuine decision. The old draft alone should be a plausible but wrong answer; the later test plus the colleague’s explanation makes the correct choice understandable. Present evidence fairly and redundantly enough that it is possible to solve without guessing. Actions have clear feedback, and an incorrect attempt leads to helpful contextual feedback, not a hard reset.
- **Resolution:** Show the consequences of the correct choice in the world and let the story breathe. The player has completed a specific human task, not merely collected objects. Resolve the narrative independently of whether the visitor chooses to learn about Evo.
- **Product transition:** After the story, offer a restrained, clearly branded explanation that the game is a metaphor, not a recording or demonstration of app capabilities. Suggested copy: “Work can be scattered. The context connecting it shouldn’t have to be.” Follow with a truthful explanation of current product maturity and clear options to learn more, get the app if genuinely available, or continue exploring. Provide the same direct product route before and during play.

The desired full experience is **10–20 minutes**, but this is a design target, not a metric you may claim without testing. Include a clear skip path; make it possible to pause/resume, and do not create artificial waiting to meet a target runtime. A short compelling core with optional exploration is better than padded gameplay.

### Game design requirements

- Establish a small set of satisfying verbs—movement, inspection, conversation and physical manipulation—that are responsive and readable on desktop and touch devices.
- Build curiosity through meaningful landmarks, environmental cues, character behavior, surprising details and questions whose answers the player can actually discover. Do not rely on inaccessible tiny text or audio-only clues.
- Make the interactions affect the world: objects respond physically, characters react, mechanisms change state, sounds match actions, and the player sees the result of a decision. Do not fake interactivity with an image or force long modal reading sequences to carry all story beats.
- Include optional, delightful interactions that reveal character or atmosphere without distracting from the core story. Avoid irrelevant minigames, filler fetch quests, punishing timers and repetitive button pressing.
- Provide an unobtrusive notebook/recap of **fictional game discoveries**, optional tiered hints and a route back from mistakes. Make order-independent progress possible and test all clue-order combinations. The notebook must never read the visitor’s actual computer activity.
- Camera and movement should feel deliberately tuned, with clear interaction range, collision and spatial navigation. Guide through composition, light, silhouette and landmarks, with optional explicit guidance rather than relying solely on color or sound.
- Treat conversion psychology responsibly. Use discovery, autonomy, honest curiosity and a satisfying experience—not fabricated scarcity, misleading claims, dark patterns, locked exits or the promise that players will automatically buy. Test effectiveness; do not claim outcomes in advance.

## 4. Product truth and safety constraints

Evo’s current state is **early**. Treat it as a local-first-in-direction macOS MVP/query prototype, not a proven finished product. Validate the repository and current release before asserting details. Agent integration, granular permissions and other advanced controls are future work unless verified as shipped. Do not claim that Evo perfectly understands all work, restores exact sessions, guarantees privacy or securely performs agent actions.

**Evo must not capture screenshots or screen recordings, even transiently.** Do not implement or suggest screenshot/video capture, screen capture permissions, frame buffers/thumbnails of the user’s screen or OCR from captured screen images as a workaround. The website’s game renders its own original fictional graphics; it must not inspect the visitor’s real screen, files, browsing history or work context.

The previously inspected Evo download page explicitly said the first build was not attached, and its download links led to a setup/thank-you page rather than an installer. That may have changed: **verify a real installer and its destination before using a Download button**. If none is provided or verified, make availability clear, offer a truthful contact/update route, and do not ship a fake download. The address `hello@evo.app` appeared on an existing Evo contact page but ownership is unverified; confirm with the owner before production use. Do not invent prices, customer numbers, social proof, endorsements, reviews, adoption, telemetry or conversion rates.

## 5. Visual system and craft requirements

Produce an original visual development package as part of the work: style frames, environment/character references, a color script, shot and camera references, interface sketches, asset list, sound direction and a short rationale. Attach or include actual images with the delivered work where your tools allow; mark generated concept images as concept art, not screenshots. Show the owner enough to evaluate the direction, but continue through to the actual implementation unless a critical missing input blocks safe completion.

Specify and implement:

- **Environment:** a coherent world with distinctive architecture, well-composed sightlines, layered foreground/midground/background, a believable scale, high-quality materials, consistent art direction and purposeful environmental details. Avoid visual emptiness and asset-pack inconsistency.
- **Characters:** appealing, adult-appropriate designs with clear silhouettes, natural idle and walking motion, believable orientation and interaction gestures. No featureless primitive dolls. Source or create assets with documented rights, and ensure animation and rigging work in-browser.
- **Lighting and atmosphere:** art-directed key/fill/practical lighting, readable shadows, depth and selective color contrast. Environmental motion should be subtle and meaningful. Don’t use bloom or fog to hide lack of detail.
- **Color:** create a deliberate, limited palette and an act-by-act color script, with values/contrast tested in grayscale and under color-vision simulations. Colors can support hierarchy and atmosphere, but color psychology is context- and culture-dependent; do not assert that a hue guarantees trust, calm, purchase or conversion. Consider https://miopap.aspu.am/index.php/miopap/article/view/64 .
- **Typography and UI:** mature, excellent typography, restrained interface, high contrast, legible text and semantic HTML for UI where practical. Avoid long overlays that hide the world, illegible tiny type and generic card layouts. Use responsive sizing, keyboard focus and adaptable text. Type must integrate with the world without making essential clues dependent on decorative or baked-in text.
- **Motion and feel:** polished start/stop and turning, smooth camera follow, responsive controls, contextual animations, correct easing, coherent transitions, visible interaction feedback, and reduced-motion options. Measure frame pacing and input latency on representative devices; do not merely assert smoothness.
- **Sound:** original or properly licensed music and environmental sounds: a memorable, subtle musical identity, meaningful reactive audio, footsteps and object sounds. Avoid a bare oscillator drone or random notes as “music.” Sound begins only after the visitor chooses it; mute, independent volume controls, captions and visual equivalents for all necessary cues are available. Browser autoplay restrictions: https://developer.mozilla.org/en-US/docs/Web/Media/Guides/Autoplay .

The experience must still be comprehensible and operable without audio; provide captions and transcripts. Protect users from motion sickness: stable camera, sensitivity control, reduced motion, no unnecessary camera shake or forced fast spins.

## 6. Engineering and production expectations

Use the stack best suited to the quality and constraints—e.g. WebGL with Three.js and glTF, or another justified browser-capable engine. Choose based on the ability to deliver robust, performant results, not trendiness. Build the real interactive game; do not deliver pseudo-code or a static conceptual mockup.

- Create a clean, complete repository/folder, with an appropriate build system and reproducible commands. No dependency on external services or credentials to load core content unless explicitly documented and approved.
- Use actual original or properly licensed 3D assets, rigs, animation, textures, music, fonts and SFX. Provide an asset provenance and licensing manifest with exact sources, creator, license, attribution and permitted commercial use. Do not include unlicensed assets or proprietary content scraped from reference sites. Flag uncertainty rather than inventing rights.
- Use physically plausible movement, deliberate collision, coherent world scale and responsive interactions. Make game state explicit; prevent soft locks, inaccessible clues and order-dependent bugs. Support pause, local save/resume and clear progress. Disclose storage. Do not use personal-work data for the fictional experience.
- Deliver desktop keyboard/mouse support and mobile touch controls; test touch sizing, interaction focus, landscape/portrait, device pixel ratio and browser UI. Provide a meaningful accessible product/story fallback when WebGL or the full experience is unavailable. Support keyboard navigation and accessibility options; do not claim full accessibility without testing. Start from https://gameaccessibilityguidelines.com/basic/ .
- Optimize geometry, textures, draw calls, loading, audio, memory and transitions. Use appropriate compression, LOD, instancing, lazy loading and device-quality settings as supported. Test actual mobile hardware where available; emulation is not proof of mobile performance. Track frame-time consistency, load time, transfer size and memory; choose and report budgets measured on named devices/network conditions. Provide WebGL failure/context-loss recovery and fallback.
- Render text and controls accessibly outside the canvas where appropriate; include correct alt descriptions, focus management, readable labels and reduced-motion handling. Never rely only on color or audio for a puzzle answer.
- Work behind a proxied preview: bind the server to `0.0.0.0` and avoid browser calls to localhost for separate services; use relative paths and proxy if needed. Ensure the app accepts the preview host. No exposed secrets.
- No nonessential analytics by default. If analytics are requested, disclose exactly what is collected, obtain any required consent, and never collect real screen content or work data. Use privacy-preserving testing.

## 7. Work process: research, build, playtest, iterate

Do not immediately generate a generic website. First inspect the actual product repository and references; determine the product’s capabilities, installer availability and existing constraints. Review the reference experiences visually and interactively where possible and be explicit about anything you could not access.

Develop an original creative treatment with a complete clue graph, narrative beats, level map, palette and sound direction. Then build and review a **representative vertical slice with target-quality art and one complete interaction**. A vertical slice is a risk-reduction step, not the final deliverable: if it meets the quality bar, proceed through the full 10–20-minute experience and all direct product/skip routes. If it does not meet the bar, iterate or clearly identify the blocker; never pad a crude prototype and claim it is finished.

Review actual screenshots and real interactions on multiple viewports. Play through personally; observe navigation, camera, loading, mobile controls, animation, puzzles and pacing. When possible test with unfamiliar adults from the target audiences and non-technical users; distinguish diagnostic small-sample feedback from statistically reliable evidence. Iterate based on observed points of confusion and friction. Specific checks include:

1. Start muted and with sound; change levels; background/return; reduced motion and captions.
2. Keyboard, pointer, touch and focus handling; interact without precision dragging; readable text and visual clues.
3. All clue orders, wrong decisions, correct decision, hints, pause, save/resume, restart and skip.
4. Game completion without being forced into a product conversion; direct product route without playing.
5. Mobile/desktop layouts, common browsers, low bandwidth, failed assets, WebGL unsupported/context loss, safe fallback.
6. Performance measurements and no blocking console errors; check actual deployment and relative asset paths.
7. Actual installer status, contact ownership, product claims, asset licenses and a clean legal/attribution handoff.

A visually impressive screenshot is not evidence of a smooth, enjoyable or complete game. A game mechanic is not successful until a player can understand and use it. If the environment prevents a test, record exactly what was and was not verified.

## 8. Final deliverables

1. **A complete, runnable, polished website/game**, not just a design document, mockup, partial code or AI-generated image.
2. A self-contained source folder and an easy ZIP with build/run instructions and a clear production deployment path. Include a live preview if the environment supports it and provide a direct working download link if publishing is authorized.
3. A short player guide, accessibility options, troubleshooting and honest status of installer/product links.
4. Creative and asset documentation: style frames, color script, scene and clue maps, sound direction, credits and commercial-use licensing/provenance.
5. A concise QA report: what was tested, device/browser details, measured performance, known limitations and anything not verified. Never claim tests, rights, quality or conversion results you did not actually establish.

If achieving the intended game-quality graphics or animation is impossible with the available tools, assets or licenses, **say so explicitly**. Deliver the best genuinely functional portion you can, label it accurately, and explain what professional assets, skills or inputs are needed. Do not call primitive placeholder geometry a polished finished game. Ask only for critical information you cannot safely infer, such as a verified installer or licensed asset source, while continuing with everything else that can be completed without it.
