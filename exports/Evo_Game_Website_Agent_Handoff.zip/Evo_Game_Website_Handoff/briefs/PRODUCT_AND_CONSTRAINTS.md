# Product and user constraints

## Product, verified boundaries and open inputs

- Evo's broader ambition is personal work continuity across digital contexts for people globally. The immediate product has been described as a local-first-in-direction early macOS MVP/query prototype; inspect the current source and release before making precise claims. The game is a metaphor, not proof that a feature has shipped.
- Do not claim production-ready AI-agent integration, fine-grained agent permissions, guaranteed safe actions, full understanding of unfinished work, exact session restoration, cross-device sync or Windows support without independent verification. Differentiate implementation, prototype and roadmap. Don't promise privacy or security outcomes that haven't been verified.
- **No screenshots or screen recordings of a user's screen, even transiently.** No screen capture permission, captured image buffers/thumbnails, video or OCR from screen images as a workaround. Game visuals are original synthetic content; the website must not inspect a user's real screen, files, browsing history or work activity.
- Earlier inspection of `origin/main:site/download.html` found that buttons led to a thank-you page and the page stated that the first build was not attached. This is a historical observation, not proof of present status. Verify the current installer and distribution rights before displaying an actual download. If none is verified, explain availability honestly and provide an approved alternative. Do not invent a price.
- `hello@evo.app` appeared in an older Evo contact page; ownership was not independently verified. Confirm before production.
- Do not invent customers, endorsements, usage metrics, conversions, purchase guarantees or testimonials. The game should invite interest without deceptive pressure.

## What the owner asked for

- A whole immersive website that is itself a fun, suspenseful browser game, telling a complete story about interrupted/scattered work and the need for context, eventually introducing Evo.
- References: Messenger by Abeto, Igloo Inc and Getty's Persepolis Reimagined. Messenger is the closest interactive reference. The next agent should study them itself.
- Mature, compelling, professional visuals and smooth gameplay fit for founders, engineers, corporate professionals and others. No childish primitive low-poly prototype, incoherent art, fake 3D or generic AI imagery.
- Either a fully realized animated/stylized visual direction or a convincingly realistic one, chosen deliberately. Maintain coherent music and sound, offered by choice.
- Around 10–20 minutes as a target with an always-available option to skip the game and visit the real product/download-or-availability path. The target needs testing; do not pad.
- User asked for end-to-end finished deliverable and a research/design/build/test process, not a shallow prompt or mockup. If required quality cannot be met, be candid.

## Existing brand information (direction, not a hard art palette)

An earlier internal logo brief described Evo as continuous, quiet, precise, warm and disciplined, with charcoal `#15181A`–`#0F1214`, caramel `#C89B6B`, teal `#5B8A8F`, and light ink `#ECEAE6`. That was a logo exploration, not proof of a final approved brand system. Do not blindly apply it to the game: validate the latest brand assets and choose a cohesive palette appropriate to the experience.
