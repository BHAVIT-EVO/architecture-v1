# THE THREAD BETWEEN
## Evo interactive experience — creative, game design and production brief

**Status:** pre-production proposal, 19 October 2026. This replaces the lighthouse story in the earlier treatment; none of the gameplay, visual quality, performance or conversion claims have been validated. The image `visual-target.png` is AI-generated concept art, not a game screenshot or a final asset.

## 1. The experience in one sentence

Explore a small coastal research station and help someone recover a half-finished idea before a community demonstration: the solution isn't hidden in one place, but in the relationships between a conversation, a test, a design and a decision.

**Format:** original single-player browser game, 10–20 minutes target, desktop and mobile. The target is a hypothesis; observed playtime determines the final scope. Visible routes to **Play**, **About Evo** and **Get Evo / availability** from the outset; skip or return to product information at any time.

**Core feeling:** “I know this feeling—and I figured it out.”

**Design pillars:**
1. A real, recognizable unfinished project, not an abstract commercial metaphor.
2. A place worth exploring and characters worth meeting, even if there were no product reveal.
3. A small number of satisfying, understandable interactions with meaningful consequences.
4. Tension from questions and a human deadline, never an actual punitive countdown.
5. Respect for the player: honest product identity, optional help, no deceptive scarcity or false installer.

## 2. The world and the real-world anchor

A small community is preparing to demonstrate an early storm-warning board at a gathering the next morning. The board is a fictional prototype: a simple display at the harbor that will tell residents whether a path near the water is safe to use. It is not a product claim, a medical/emergency tool, or an actual safety recommendation.

Mara, a local maker, has been preparing the demo. Yesterday she stopped mid-task to help with a storm-related interruption. The player arrives to help finish the demonstration. Mara is safe and in contact—there is no false missing-person crisis. Her notes are scattered between a workshop, a field observation and a conversation with a colleague. The player must reconstruct **the latest decision**, not just collect three things.

This is relatable to founders presenting a prototype, engineers debugging a change and office workers picking up a project, without requiring the player to identify with any profession. We should test that assumption rather than claim it is universal.

**Why someone cares:** the community wants to know if the proposed path-warning display will be understandable during a storm. Mara worries her incomplete demo could present an old, misleading design. Finishing means choosing the latest intended behavior and presenting it clearly; not delivering a grand rescue fantasy.

## 3. The story, interaction by interaction

Times are design targets, not measured durations. The player can visit the workshop, harbor and relay hut in different orders after the initial hook. Clue content remains accessible and progression never relies on visiting them in a prescribed sequence.

### Entry / first minute: Something is off

**View:** station at blue hour. Warm workshop window; a radio mast is silhouetted at the end of a path. A display on the harbor briefly flashes “PATH OPEN,” then a paper notice beside it says “testing only.” A gust scatters one loose sheet. The player has a question, not a wall of instructions.

**Choices:** Enter with sound / enter muted; About Evo; Get Evo or accurate availability. An unobtrusive, accessible menu remains available throughout. Browser sound is initialized only after user interaction.

**First action:** walk to the loose sheet and interact. It is a rough sketch of the board with two layouts: an older **sun icon** and a newer **wave icon**. The sheet alone does not say which is correct. It points to a workshop note: “Ask Noor about the test.” The character's first companion interaction is optional: a harbor cat noses a pencil, knocking it gently; interacting again gets a different animation, not an endlessly repeated line.

**Player question:** Why are there two versions, and which one should be shown tomorrow?

### Workshop: The obvious answer is not enough

The workspace has an open laptop, paper sketches and a half-built board. These are fictional authored props, not live user data. A message from Mara reads: “I changed the warning after Noor's test. The version in the draft folder is old. I left the next step where we tested it.” A draft displays the sun layout. Pressing the board's demo button shows the sun layout and the fictional label “PATH OPEN”; a yellow TESTING label and a harmless mismatch cue appear. The player can try it; no penalty or long error animation.

**Interactive toy:** rotate the display's small weather shield and see rain bounce off its surface. This is playful environmental feedback, not a gate. Interactables have consistent shape, sound and focus cues, not color alone.

The player can open an in-game pocket notebook. It records discovered clues with short summaries and sources, not undiscovered solutions. It offers a reminder of the open question and an optional hint; it never reads the visitor's files.

### Harbor: Hear what happened

Noor, an approachable harbor caretaker, is checking the board. A compact dialogue with two choices lets the player ask about the test or tomorrow's demonstration. The important answer is accessible through either route and remains repeatable in the notebook:

> “We tried the sun symbol during the rain. A few people thought it meant the path was safe. Mara said she'd change it to the wave and add words. We tested it by the relay hut.”

This establishes **why** the old design changed. An optional exchange tells us Noor has been preparing the space for neighbors; warmth and personality, no product lecture.

### Relay hut: Recover the next step through play

A little wind-driven sign sits beside a rain shelter. The player rotates the shelter's hinged panels to uncover a work surface and a test sheet underneath. This takes one obvious manipulation, with object movement, sound and a visual state change. It is a small tactile toy, not a complicated unrelated lock.

The test sheet says: “Latest test — wave + words: PATH CLOSED. Demo mode only. Next: update workshop board and show Noor.” The sheet is signed by Mara and marked after the draft. The information is readable at the hut, also summarized in the notebook, and available without hearing audio. If the player visited the hut first, the clue works independently; subsequent dialogue explains its context.

### Return: Make a meaningful decision

At the workshop, the player sets the board through two simple controls: choose between sun and wave icons; choose between PATH OPEN and PATH CLOSED. The old draft supplies the misleading combination; Noor explains the problem; the test sheet supplies the latest choice. Correct answer: **wave + PATH CLOSED**.

The player may choose incorrectly. The board responds with an understandable physical result and Noor's accessible feedback: “That looks like the version that confused us. Maybe check what changed after the test.” No reset, no shame, no repeated backtracking; the notebook lists already discovered clues. If essential evidence was missed, contextual optional hints point to the relevant place. The game supports direct actions when the player has already deduced the answer; the content does not force a document-collection checklist.

### Resolution: Show, don't preach

Take the board to Noor using a short transition, not a tedious inventory walk. The player presses the demo button; the fictional board displays **wave + PATH CLOSED** with a visible **DEMONSTRATION** tag. Noor: “That's the one. Now people can tell what we mean.” Mara calls, relieved: “I knew we'd worked it out. I just couldn't remember where we'd left it.”

The camera settles over the harbor; the station lights come on. A short, quiet musical resolution plays if enabled. The player has finished a specific human task and understands why the choice mattered. Stay and explore, or continue.

### Optional Evo bridge

After the story resolves, a modest, clearly branded panel says: “Work can be scattered. The context connecting it shouldn't have to be.” Then: “Evo is an early local-first project exploring ways to find your way back to your work.” Choices: **Learn about Evo**, **Get Evo / availability**, **Stay on the island**.

The game is a metaphor and does not demonstrate an actual feature. Validate every product detail before launch. Agent integrations and granular permissions are future work. No screenshots or screen recording. Current repository download page states the first build is not attached; do not claim a working installer, price, release status or feature completion without verification.

## 4. Fun, agency and pacing

**Core loop:** notice → explore → interact → learn → connect → try → see a consequence. Optional diversions include a playful cat, a wind vane, a bell with changing resonance and a hidden handwritten note; these are rewards in themselves and never mandatory. Three primary verbs: **move**, **inspect/talk**, **manipulate/select**. No combat, health bar, timers, forced cutscenes, manufactured loss or filler.

**Minute-to-minute rhythm:** 0–2 hook and first interaction; 2–6 investigate either location and learn the old version is misleading; 6–12 physical hut interaction and choice of where to go next; 12–17 assemble the latest decision, test it and resolve; optional exploration thereafter. These are untested pacing targets. Shrink, expand or cut beats based on observed play.

**Hint ladder:** first show the player's current question; on request, point to the relevant type of evidence; on a second request, identify the location; on a third, state the next action. No timer forces a hint. Returning players have an optional concise recap.

## 5. Spatial plan and navigation

A compact triangular loop: **workshop ↔ harbor ↔ relay hut ↔ workshop**. The mast is visible from both other locations; workshop is identified by a warm window and distinct roof; harbor has a boat crane and waterline. Use paths, silhouettes, lighting and movement to create discoverable sightlines, but provide an optional accessible map/directional aid. Ensure landmarks remain visible from key junctions and different camera angles. Test without relying on the player recognizing hue or hearing sound.

Camera: third-person, slightly elevated follow camera with stable horizon. Gentle framing changes only where they help reveal a clue; no forced spins. Adjustable sensitivity, reduced camera movement, snap-to-target interaction and static camera alternatives where feasible. Avoid forced perspective changes during puzzles. No promise of controller support until implemented and tested.

## 6. Art direction and color script

**North star:** a place with warmth, mystery and touch—not a productivity dashboard dressed in 3D. Concept image `visual-target.png` illustrates atmosphere, proposed camera and landmark hierarchy. It is not evidence that the final game will look identical.

**Visual style:** stylized-realistic miniature environment with deliberately authored forms and believable materials; geometry that reads clearly at phone size; restrained, cohesive environmental detail. The quality should come from composition, animation, light, material and sound as a system. Avoid generic luminous orbs, procedural noise, decorative interface cards, fake screenshots, random assets and over-processed bloom. Concept art may be generated; production assets must have clear rights and consistency. No copying Messenger's world, music, characters or models.

**Proposed palette, editable after tests:**
- Deep slate `#263746`: distant dusk and shadows; provides contrast, not a claim that blue universally creates calm.
- Sea mist `#758D8D`: atmosphere and distant layers; preserve readable silhouette separation.
- Weathered pine `#465D50`: grasses and foliage; texture and place.
- Warm lamp `#E3AE6D`: selected inhabited windows and practical light; draws attention against cool surroundings, not a magic conversion color.
- Paper `#F2E8D4`: notes and readable panels; use dark ink and verify contrast.
- Oxide `#AF6956`: rare material accent; never the sole success/error signal.

**Color script:** arrival = cool slate/sea mist with one warm window; investigation = subtle neutral-warm work interiors contrasted against dusk; decision = focused light on the board with subdued surroundings; resolution = warmed windows and slightly brighter horizon while retaining the same world. Changes are authored state transitions, not a false timer or sudden emotional manipulation. Test in grayscale, varied displays and color-vision simulations.

**Research limits:** color-emotion associations vary with context, culture and individual differences; findings do not prove a hue causes a purchase or guarantees a mood. Color serves composition and contrast here and remains a testable creative choice. Review: https://miopap.aspu.am/index.php/miopap/article/view/64

**Lighting and graphics:** one readable key light, soft fill and intentional practical lights; fog used for depth without hiding puzzle objects. Bake/static-light where suitable; prioritize crisp silhouettes, shadow contact, consistent scale, cohesive materials and responsive character animation over expensive effects. Practical interactive feedback: object depresses/rotates, nearby material responds, sound is synchronized, focus state is visible. Aim for stable frame pacing over maximum fidelity. Real-time quality must be measured, not inferred from concept art.

**Typography:** one highly legible UI family and a distinct, restrained display face for title/chapters; select after testing licensing and real rendering. Body and clues use plain language, generous line-height and adjustable size. Avoid using distressed handwritten type for essential information. Controls, dialogs and product information should be semantic HTML where practical, not text baked into world textures.

## 7. Sound and emotional direction

Original or appropriately licensed score and sound assets only. Target: delicate motifs, soft piano or mallet tones, air and restrained low strings; warm and curious with a little uncertainty, not horror music or constant dramatic crescendos. Music layers respond to broad story states and fade gracefully; optional effects include wind in grass, footsteps on gravel/wood, the shelter hinge, board switches and water. Sound enriches the place; all essential clues are available as text and visuals. Independent music/effects controls, captions and mute. No sound without a deliberate entry gesture; browser restrictions vary (https://developer.mozilla.org/en-US/docs/Web/Media/Guides/Autoplay). No sourced track is yet selected or licensed.

## 8. Accessibility and mobile

- Options accessible before play: captions, text scaling, music/effects levels, reduced motion, input sensitivity, high contrast and simplified controls. Controls remapping and keyboard-only operation where supported; never promise full accessibility without testing.
- No color-only puzzle logic, mandatory audio cue, timed input, flashing effects or fine drag requirement. Tap/select alternative for manipulations; spoken dialogue accompanied by readable captions and speaker labels.
- Use semantic DOM menus and an accessible story/product route if WebGL is unsupported, too slow, or the player prefers not to play in 3D. That route must explain the real product independently, not act as a broken-game dead end.
- Mobile: test on actual iOS and Android browsers; touch joystick or tap-to-move to be compared in playtests, large separated targets, orientation changes and pause/resume. Do not assume responsive CSS makes a 3D game usable.
- Use game accessibility guidelines as a starting checklist, not a certification: https://gameaccessibilityguidelines.com/basic/

## 9. Implementation, assets and performance plan

Candidate stack: Three.js/WebGL with a conventional semantic HTML shell, glTF assets, an explicit state machine for clues and story, and a locally hosted, rights-cleared audio pipeline. Choose only after the visual slice and target device tests; WebGL or an engine does not produce quality by itself.

**Asset inventory:** player character and basic animation; Mara/Noor character presentation; one workshop exterior/interior, one harbor vista, one relay-hut scene; three hero props (board, notebook, hinged shelter); foliage and terrain; icons/UI/type; ambient score and SFX. Establish source, license, edits and provenance for every model, texture, font and sound. Build coherent original assets rather than stitch incompatible asset-pack aesthetics together. AI concept art is reference only and not automatically usable as a 3D level.

**Initial engineering budgets (hypotheses to measure):** target 60 fps on a representative desktop, 30 fps or better on a representative phone; progressive/lazy loading by area; cap device pixel ratio when needed; set transfer and memory budgets after a measured slice. Test frame-time percentiles, actual network transfer and memory on mid-range devices, not just desktop averages. Use texture/mesh compression where supported, instancing/LOD, baked lighting and disposal; compressed downloads alone do not guarantee low runtime memory. Provide fallback on WebGL failure/context loss, reconnect/resume and no audio. Preserve semantic content when JavaScript fails where possible.

**State model:** discovered clues stored separately from optional interactions; board choice and completion states explicit; no dependency on clue visit order. Save fictional game progress locally, clearly disclosed with a clear/delete option. No actual file access, screenshots, screen recordings, OCR, screen capture, or real browsing data. No analytics until purpose, consent and privacy behavior are decided.

## 10. Proof gates and playtesting

**Gate A — paper/interactive flow:** unmoderated observation with people unfamiliar with Evo, including founders, developers, corporate workers and non-technical participants. Ask what they believe the goal is, what they think changed, what they try next; record consented observations and identify failures, not only praise. No claims of representative conversion from a small convenience sample.

**Gate B — vertical slice:** workshop-to-harbor area with final-intent art, player movement, one character, one tactile interaction, one clue, sound choice and reduced-motion/mobile alternatives. Do not expand until the player can control the character, understands the question, notices an optional interaction, and wants to continue without explanation. Target criteria, not fake results: at least 4 of 5 initial desktop playtesters can discover the first clue without moderator prompting; no blocker or unrecoverable state; evidence of desire to continue collected as free text. A small sample is diagnostic, not statistical proof. Run separate mobile and accessibility sessions; widen testing and revise thresholds as needed.

**Gate C — full narrative:** test visit-order permutations, repeat/incorrect interactions, hints, save/resume, mute, focus, keyboard/touch, low bandwidth, WebGL failure and actual device performance. Ask what Evo does after the ending; if people believe the game is a real app demonstration, clarify the product bridge. Track optional continuation, completion and voluntary product interest only with consent and appropriate disclosure; compare with a non-game product route if evaluating efficacy. Do not equate clicks or purchases with successful onboarding or promise outcomes.

## 11. Sources and design implications

- **Messenger:** an explorable small world and a concrete delivery verb; inspiration is agency and texture, not cloned content. Secondary review, not independent play verification: https://www.rockpapershotgun.com/messenger-is-an-absurdly-slick-perfectly-lovely-free-pocket-world-exploration-game-you-can-play-in-a-browser
- **Persepolis:** Getty describes the guided 3D walk and contextual exploration; a source for spatial storytelling, not evidence our game will match its fidelity: https://www.getty.edu/news/persia-ancient-iran-and-the-classical-world-at-the-getty-villa-museum/
- **Outer Wilds:** designer interview on landmarks, clues and curiosity; also notes accessibility and avoiding punishing players for getting lost: https://www.pointnthink.fr/en/loan-verneau-creative-lead-at-mobius-digital-on-outer-wilds/
- **Firewatch:** artist describes environmental wayfinding and tension between clear direction and player discovery: https://www.newyorker.com/tech/annals-of-technology/with-firewatch-olly-moss-brings-his-subversive-touch-to-video-games
- **Chicory:** designer Greg Lobanov discusses playful, toy-like puzzle interactions and the need to revise ideas players don't enjoy: https://gdconf.com/article/making-the-wondrous-world-of-chicory-a-colorful-tale-with-greg-lobanov-gdc-podcast-ep-26/
- **Player motivation:** four studies associate perceived autonomy and competence with enjoyment; context-limited findings, not a formula for our game or conversion: https://www.academia.edu/24486969/The_Motivational_Pull_of_Video_Games_A_Self_Determination_Theory_Approach
- **Color:** the 2025 review notes cultural/contextual variation and methodological limitations: https://miopap.aspu.am/index.php/miopap/article/view/64
- **Accessibility:** basic guidelines include remapping, text sizing, color-blindness and subtitle presentation: https://gameaccessibilityguidelines.com/basic/

**Reference limitation:** original sites could not all be fully played in this environment; findings include primary site descriptions, designer interviews and secondary reports, not a claim of complete first-hand playthroughs.
