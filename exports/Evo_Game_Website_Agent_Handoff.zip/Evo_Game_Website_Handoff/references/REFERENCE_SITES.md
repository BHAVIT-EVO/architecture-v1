# References to study independently

## The owner's three primary references

1. **Messenger, Abeto** — https://messenger.abeto.co/ — closest to the desired feeling of a playable, explorable game. Study movement, game loop, environment, storytelling, camera, sound, interaction feedback and production craft. Do not copy assets or content.
2. **Igloo Inc** — https://www.igloo.inc/ — study immersive world-building, lighting, art direction, environmental motion and sound. Do not copy its identity or assets.
3. **Persepolis Reimagined, Getty** — https://persepolis.getty.edu/ — study spatial storytelling, environmental immersion, structure, presentation and audio. Do not copy its assets or historical setting.

Visit and interact directly where available; if unable, record what could not be verified. The owner wants the next agent to reach its own informed conclusions, not merely follow a second-hand summary.

## Supporting research (not substitutes for the originals)

- Getty explains Persepolis Reimagined: https://www.getty.edu/news/persia-ancient-iran-and-the-classical-world-at-the-getty-villa-museum/
- Reporting on Messenger: https://www.rockpapershotgun.com/messenger-is-an-absurdly-slick-perfectly-lovely-free-pocket-world-exploration-game-you-can-play-in-a-browser
- Outer Wilds creative lead on curiosity-led exploration and accessibility: https://www.pointnthink.fr/en/loan-verneau-creative-lead-at-mobius-digital-on-outer-wilds/
- Firewatch environmental art and wayfinding: https://www.newyorker.com/tech/annals-of-technology/with-firewatch-olly-moss-brings-his-subversive-touch-to-video-games
- Chicory designer on playful puzzle design and iteration: https://gdconf.com/article/making-the-wondrous-world-of-chicory-a-colorful-tale-with-greg-lobanov-gdc-podcast-ep-26/
- Color/design review, with contextual and methodological limits: https://miopap.aspu.am/index.php/miopap/article/view/64
- Game accessibility checklist: https://gameaccessibilityguidelines.com/basic/
- Browser audio autoplay restrictions: https://developer.mozilla.org/en-US/docs/Web/Media/Guides/Autoplay

## Optional visual

`optional-atmosphere-concept.png` is an AI-generated concept from an earlier exploration. It is **not** an approved direction or final screenshot. Discard it if it constrains a better, original design. No assets from the reference sites are included or licensed here.
