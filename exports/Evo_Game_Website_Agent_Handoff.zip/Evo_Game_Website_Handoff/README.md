# Evo — immersive website & game handoff

## Start here

1. Read `briefs/MASTER_PROMPT.md` as the end-to-end assignment.
2. Read `briefs/INDEPENDENT_CREATIVE_DIRECTION.md` next. It clarifies where the next agent has creative freedom and takes precedence over any rigid-sounding wording in the master prompt.
3. Read `briefs/PRODUCT_AND_CONSTRAINTS.md` for claim boundaries and user decisions.
4. Use `references/REFERENCE_SITES.md` to visit the user's actual references. Study and play them independently wherever access allows.
5. `briefs/EXPLORATORY_TREATMENT.md` and `references/optional-atmosphere-concept.png` are **previous exploration only**, not mandatory design, approved art or product screenshots. They are provided for context, not as instructions to copy them.

The owner wants a complete, professional website/game, not merely a plan. The assignment includes research, visual development, a target-quality playable slice, then a complete build, testing and handoff. Make your own creative decisions based on direct reference study and the product, while respecting the user's constraints. Be transparent about limitations, licensing and testing; do not claim work or quality you cannot demonstrate.

## What's not included

No app source, actual installer, verified contact destination, production brand package, licensed 3D assets or music are included. The next agent should inspect the actual Evo repository if available and obtain/verify these before asserting capabilities or linking a download. The mood image is AI-generated and is not a licensed production asset. No private browsing corpus or rejected website/game implementations are included.
